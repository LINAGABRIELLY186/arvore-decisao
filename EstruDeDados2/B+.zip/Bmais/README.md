Sistema de Clientes 

Grupo: Lina, Luana, MeirNaã e Teresa

> Funcionalidades:
Inserção de clientes:
Grava cliente no clientes.dat
Insere chave na árvore B+
Se nó cheio, divide e promove chave

Busca por código:
Percorre a árvore do nó raiz até folha correta
Busca chave na folha, obtém RRN do cliente
Lê e imprime o cliente do arquivo clientes.dat

Busca ordenada:
Percorre as folhas usando o encadeamento via proximaFolha
Imprime todos os clientes em ordem crescente
